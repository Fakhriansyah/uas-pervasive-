package com.example.ui_trasactviewi_2379318455

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
